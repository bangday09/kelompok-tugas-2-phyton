import StudentCRUDApp from "./Apaya.tsx";

function App() {
  return <StudentCRUDApp />;
}

export default App;
